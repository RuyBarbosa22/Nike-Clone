const CustomerReviews = () => {
  return (
    <div>
      CustomerReviews
    </div>
  )
}

export default CustomerReviews
