const Subscribe = () => {
  return (
    <div>
      Subscribe
    </div>
  )
}

export default Subscribe
